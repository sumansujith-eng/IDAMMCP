Capgemini spade symbol (supplied): assets/capgemini-spade.jpg - used in the login hero, sign-in form and sidebar.
Replace with a transparent SVG of the same name for a crisper result.
