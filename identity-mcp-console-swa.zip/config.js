// Capgemini Identity MCP Console — DEVELOPMENT environment defaults.
// This file is served to every browser that opens the page: keep it off public repos / public URLs and rotate the dev secrets when done.
window.IMC_CONFIG = {
  // Microsoft Entra ID — delegated sign-in via MSAL (SPA). Client secret is NOT used or stored (browsers can't hold one safely).
  entraMode: 'live',
  tenant: '8ee51404-402a-48a8-8915-e02c8d224a77',
  client: '4633087e-6d2e-45b3-9017-2658cb0c1ec7',   // app registration: servicenowEntraConnect

  // ServiceNow Table API
  snowMode: 'live',
  snowUrl: 'https://dev343219.service-now.com',
  snowUser: 'mcpadmin',
  snowPass: 'Automation@123!',
  closeCode: 'Solved (Permanently)',
  resolvedState: '6',

  // Azure AI Foundry — gpt-4.1 deployment
  aiMode: 'live',
  aiUrl: 'https://iam-agentic-resource.cognitiveservices.azure.com/openai/deployments/gpt-4.1/chat/completions?api-version=2025-01-01-preview',
  aiModel: 'gpt-4.1',
  aiKey: 'AD5WOUWTl7Xop1lsESiSvpxK6VvgJpZHauccRgLuE7ELMhYeRf3KJQQJ99CEACHYHv6XJ3w3AAAAACOGfCmj'
};
