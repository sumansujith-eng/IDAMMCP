/* Capgemini Identity MCP Console — core: storage, crypto, session, connectors */
/* ================= Storage & helpers ================= */
const LS = {get:(k,d)=>{try{const v=localStorage.getItem('imc:'+k);return v?JSON.parse(v):d}catch{return d}}, set:(k,v)=>localStorage.setItem('imc:'+k,JSON.stringify(v))};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>crypto.randomUUID();
const now=()=>new Date().toISOString();
const fmt=t=>new Date(t).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function toast(msg,kind='',sub=''){const t=document.createElement('div');t.className='toast '+kind;t.innerHTML='<span class="tico">'+(kind==='ok'?'✓':kind==='err'?'!':'i')+'</span><div><b>'+esc(msg)+'</b>'+(sub?'<small>'+esc(sub)+'</small>':'')+'</div>';$('#toasts').appendChild(t);setTimeout(()=>t.remove(),5500)}

/* ================= Crypto (PBKDF2 + AES-GCM) ================= */
const enc=new TextEncoder(),dec=new TextDecoder();
const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b))), unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
async function hashPw(pw,salt){const k=await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveBits']);return b64(await crypto.subtle.deriveBits({name:'PBKDF2',salt:unb64(salt),iterations:120000,hash:'SHA-256'},k,256))}
async function deriveKey(pw,salt){const k=await crypto.subtle.importKey('raw',enc.encode(pw),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:new Uint8Array([...unb64(salt),...enc.encode('imc-enc-v1')]),iterations:150000,hash:'SHA-256'},k,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function encryptJson(key,obj){const iv=crypto.getRandomValues(new Uint8Array(12));const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(JSON.stringify(obj)));return{iv:b64(iv),ct:b64(ct)}}
async function decryptJson(key,blob){try{const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(blob.iv)},key,unb64(blob.ct));return JSON.parse(dec.decode(pt))}catch{return null}}
const newSalt=()=>b64(crypto.getRandomValues(new Uint8Array(16)));

/* ================= Console users & session ================= */
const S={user:null,key:null,creds:null,users:[],groups:[],apps:[],charts:{},entraAccount:null,health:{entra:null,snow:null,ai:null}};
const DEFAULT_CREDS=Object.assign({entraMode:'mock',snowMode:'mock',aiMode:'mock',tenant:'',client:'',snowUrl:'',snowUser:'',snowPass:'',closeCode:'Solved (Permanently)',resolvedState:'6',aiUrl:'',aiKey:'',aiModel:''},window.IMC_CONFIG||{});
async function seedUsers(){
  if(LS.get('users'))return;
  const mk=async(u,n,r,p)=>{const salt=newSalt();return{username:u,name:n,role:r,salt,hash:await hashPw(p,salt)}};
  LS.set('users',[await mk('admin','Sujith Kumar','Admin','Admin@123'),await mk('operator','Priya Raman','Operator','Operator@123'),await mk('viewer','Arjun Nair','Viewer','Viewer@123')]);
}
async function login(u,p){
  const acct=LS.get('users',[]).find(x=>x.username===u.trim().toLowerCase());
  if(!acct||await hashPw(p,acct.salt)!==acct.hash)return false;
  S.user=acct;S.key=await deriveKey(p,acct.salt);
  const blob=LS.get('creds:'+acct.username);S.creds=blob?(await decryptJson(S.key,blob))||{...DEFAULT_CREDS}:{...DEFAULT_CREDS};for(const k in DEFAULT_CREDS)if(S.creds[k]===''||S.creds[k]==null)S.creds[k]=DEFAULT_CREDS[k];
  return true;
}
const can=(a)=>{const r=S.user.role;if(a==='write')return r!=='Viewer';if(a==='admin')return r==='Admin';return true};

/* ================= Audit ================= */
function audit(action,target,status,details,incident){const e={id:uid(),t:now(),actor:S.user.username,action,target,status,details,incident:incident||''};const l=LS.get('audit',[]);l.unshift(e);LS.set('audit',l.slice(0,2000));return e}

/* ================= Mock directory ================= */
const MOCK={
users:[['Jane Fernandes','jane@contoso.com','Finance','Finance Manager',true],['John Mathews','john@contoso.com','Engineering','Senior Engineer',true],['Meera Iyer','meera@contoso.com','HR','HR Business Partner',true],['Rahul Verma','rahul@contoso.com','Finance','Accountant',false],['Sofia Alvarez','sofia@contoso.com','Sales','Account Executive',true],['David Chen','david@contoso.com','Engineering','Platform Lead',true],['Ananya Rao','ananya@contoso.com','Marketing','Content Lead',true],['Karim Haddad','karim@contoso.com','IT','Service Desk Analyst',true],['Lucy Brown','lucy@contoso.com','Legal','Counsel',true],['Vikram Singh','vikram@contoso.com','Sales','Sales Director',false],['Emma Wilson','emma@contoso.com','HR','Recruiter',true],['Tom Okafor','tom@contoso.com','IT','Identity Engineer',true]],
groups:['Finance-Team','Engineering-All','HR-Confidential','Sales-EMEA','IT-Admins','All-Employees','Marketing-Creative'],
apps:[['Workday','wd-role'],['Salesforce','sf-user'],['SharePoint Finance','sp-fin'],['GitHub Enterprise','gh-dev'],['ServiceNow','sn-itil']],
memberships:{'jane@contoso.com':['Finance-Team','All-Employees'],'john@contoso.com':['Engineering-All','All-Employees'],'meera@contoso.com':['HR-Confidential','All-Employees'],'rahul@contoso.com':['Finance-Team','All-Employees'],'sofia@contoso.com':['Sales-EMEA','All-Employees'],'david@contoso.com':['Engineering-All','IT-Admins','All-Employees'],'ananya@contoso.com':['Marketing-Creative','All-Employees'],'karim@contoso.com':['IT-Admins','All-Employees'],'lucy@contoso.com':['All-Employees'],'vikram@contoso.com':['Sales-EMEA','All-Employees','Finance-Team'],'emma@contoso.com':['HR-Confidential','All-Employees'],'tom@contoso.com':['IT-Admins','Engineering-All','All-Employees']},
appAssign:{'jane@contoso.com':['Workday'],'john@contoso.com':['GitHub Enterprise','Workday'],'meera@contoso.com':['Workday'],'rahul@contoso.com':['Workday','SharePoint Finance'],'sofia@contoso.com':['Salesforce','Workday'],'david@contoso.com':['GitHub Enterprise','ServiceNow','Workday'],'ananya@contoso.com':['Workday'],'karim@contoso.com':['ServiceNow','Workday'],'lucy@contoso.com':['Workday'],'vikram@contoso.com':['Salesforce'],'emma@contoso.com':['Workday'],'tom@contoso.com':['ServiceNow','GitHub Enterprise','Workday']}
};
function mockState(){let m=LS.get('mock');if(!m){m={users:MOCK.users.map(([n,u,d,j,e])=>({id:uid(),displayName:n,userPrincipalName:u,department:d,jobTitle:j,accountEnabled:e})),groups:MOCK.groups.map(g=>({id:uid(),displayName:g})),apps:MOCK.apps.map(([n,r])=>({id:uid(),displayName:n,appRoleId:uid(),roleName:r})),memberships:{},appAssign:{},incidents:[],seq:1040};
  for(const u of m.users){m.memberships[u.id]=(MOCK.memberships[u.userPrincipalName]||[]).map(g=>m.groups.find(x=>x.displayName===g).id);m.appAssign[u.id]=(MOCK.appAssign[u.userPrincipalName]||[]).map(a=>({id:uid(),resourceId:m.apps.find(x=>x.displayName===a).id}))}
  // seeded signals for the demo story: Jane lost SharePoint Finance last week
  const jane=m.users.find(u=>u.userPrincipalName==='jane@contoso.com');
  m.signIns=[{t:-2,user:jane.id,app:'Microsoft 365',status:'Success',ip:'103.21.44.9',loc:'Bengaluru, IN'},{t:-3,user:jane.id,app:'SharePoint Finance',status:'Failure: AADSTS50105 not assigned',ip:'103.21.44.9',loc:'Bengaluru, IN'},{t:-4,user:jane.id,app:'Workday',status:'Success',ip:'103.21.44.9',loc:'Bengaluru, IN'},{t:-30,user:jane.id,app:'Microsoft 365',status:'Failure: password',ip:'185.220.101.4',loc:'Frankfurt, DE'}];
  m.dirAudits=[{t:-5,target:jane.id,activity:'Remove app role assignment from user',by:'svc-jml-automation','result':'success',details:'SharePoint Finance'},{t:-6,target:jane.id,activity:'Remove member from group',by:'svc-jml-automation',result:'success',details:'Finance-Team → All-Employees only'},{t:-40,target:jane.id,activity:'Reset user password',by:'karim@contoso.com',result:'success',details:''}];
  LS.set('mock',m)}return m}
const saveMock=m=>LS.set('mock',m);

/* ================= Entra adapter ================= */
let msalApp=null;
const GRAPH='https://graph.microsoft.com/v1.0';
const SCOPES=['User.ReadWrite.All','Group.ReadWrite.All','AppRoleAssignment.ReadWrite.All','Directory.Read.All','AuditLog.Read.All'];
function ensureMsal(){const c=S.creds;if(!c.tenant||!c.client)throw new Error('Entra tenant ID and client ID are not configured');if(!window.msal)throw new Error('MSAL library failed to load');
  if(!msalApp||msalApp._cid!==c.client){msalApp=new msal.PublicClientApplication({auth:{clientId:c.client,authority:'https://login.microsoftonline.com/'+c.tenant,redirectUri:location.origin+location.pathname},cache:{cacheLocation:'sessionStorage'}});msalApp._cid=c.client;msalApp._init=msalApp.initialize()}return msalApp}
async function entraSignIn(){try{const a=ensureMsal();await a._init;const r=await a.loginPopup({scopes:SCOPES});S.entraAccount=r.account;$('#entraAcct').textContent='Signed in as '+r.account.username;toast('Entra sign-in complete','ok',r.account.username)}catch(e){toast('Entra sign-in failed','err',e.message)}}
async function graphToken(){const a=ensureMsal();await a._init;const acct=S.entraAccount||a.getAllAccounts()[0];if(!acct)throw new Error('Not signed in to Entra. Open My credentials and sign in.');try{return(await a.acquireTokenSilent({scopes:SCOPES,account:acct})).accessToken}catch{return(await a.acquireTokenPopup({scopes:SCOPES,account:acct})).accessToken}}
async function graph(method,path,body){const tok=await graphToken();const r=await fetch(GRAPH+path,{method,headers:{Authorization:'Bearer '+tok,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});if(r.status===204)return null;const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||('Graph '+r.status));return j}

const Entra={
  live:()=>S.creds.entraMode==='live',
  async listUsers(){if(!this.live()){return mockState().users}const j=await graph('GET','/users?$select=id,displayName,userPrincipalName,department,jobTitle,accountEnabled&$top=200');return j.value},
  async listGroups(){if(!this.live())return mockState().groups;return(await graph('GET','/groups?$select=id,displayName&$top=200')).value},
  async listApps(){if(!this.live())return mockState().apps;const j=await graph('GET','/servicePrincipals?$select=id,displayName,appRoles&$top=100&$filter=servicePrincipalType eq \'Application\'');return j.value.map(sp=>({id:sp.id,displayName:sp.displayName,appRoleId:(sp.appRoles?.find(r=>r.isEnabled)?.id)||'00000000-0000-0000-0000-000000000000',roleName:sp.appRoles?.[0]?.displayName||'Default'}))},
  async setEnabled(user,enabled){if(!this.live()){const m=mockState();const u=m.users.find(x=>x.id===user.id);u.accountEnabled=enabled;saveMock(m);return}await graph('PATCH','/users/'+user.id,{accountEnabled:enabled})},
  async memberOf(user){if(!this.live()){const m=mockState();return(m.memberships[user.id]||[]).map(g=>m.groups.find(x=>x.id===g)).filter(Boolean)}return(await graph('GET','/users/'+user.id+'/memberOf/microsoft.graph.group?$select=id,displayName')).value},
  async addToGroup(user,group){if(!this.live()){const m=mockState();m.memberships[user.id]=[...new Set([...(m.memberships[user.id]||[]),group.id])];saveMock(m);return}await graph('POST','/groups/'+group.id+'/members/$ref',{'@odata.id':GRAPH+'/directoryObjects/'+user.id})},
  async removeFromGroup(user,group){if(!this.live()){const m=mockState();m.memberships[user.id]=(m.memberships[user.id]||[]).filter(g=>g!==group.id);saveMock(m);return}await graph('DELETE','/groups/'+group.id+'/members/'+user.id+'/$ref')},
  async appAssignments(user){if(!this.live()){const m=mockState();return(m.appAssign[user.id]||[]).map(a=>({id:a.id,resourceId:a.resourceId,resourceDisplayName:m.apps.find(x=>x.id===a.resourceId)?.displayName}))}return(await graph('GET','/users/'+user.id+'/appRoleAssignments')).value},
  async assignApp(user,app){if(!this.live()){const m=mockState();const l=m.appAssign[user.id]||[];if(!l.some(a=>a.resourceId===app.id))l.push({id:uid(),resourceId:app.id});m.appAssign[user.id]=l;saveMock(m);return}await graph('POST','/users/'+user.id+'/appRoleAssignments',{principalId:user.id,resourceId:app.id,appRoleId:app.appRoleId})},
  async unassignApp(user,app){if(!this.live()){const m=mockState();m.appAssign[user.id]=(m.appAssign[user.id]||[]).filter(a=>a.resourceId!==app.id);saveMock(m);return}const l=await this.appAssignments(user);for(const a of l.filter(x=>x.resourceId===app.id))await graph('DELETE','/users/'+user.id+'/appRoleAssignments/'+a.id)},
  async createUser(d){if(!this.live()){const m=mockState();if(m.users.some(u=>u.userPrincipalName.toLowerCase()===d.userPrincipalName.toLowerCase()))throw new Error('UPN already exists');const u={id:uid(),accountEnabled:true,...d};m.users.push(u);m.memberships[u.id]=[];m.appAssign[u.id]=[];saveMock(m);return u}
    const pw='Tmp!'+Math.random().toString(36).slice(2,10)+'Aa1';return graph('POST','/users',{accountEnabled:true,displayName:d.displayName,mailNickname:d.userPrincipalName.split('@')[0],userPrincipalName:d.userPrincipalName,department:d.department,jobTitle:d.jobTitle,passwordProfile:{forceChangePasswordNextSignIn:true,password:pw}})},
  async updateUser(user,patch){if(!this.live()){const m=mockState();Object.assign(m.users.find(x=>x.id===user.id),patch);saveMock(m);return}await graph('PATCH','/users/'+user.id,patch)},
  async signIns(user){if(!this.live()){const m=mockState();return{ok:true,items:(m.signIns||[]).filter(s=>s.user===user.id).map(s=>({createdDateTime:new Date(Date.now()+s.t*864e5).toISOString(),appDisplayName:s.app,status:s.status,ipAddress:s.ip,location:s.loc}))}}
    try{const j=await graph('GET',"/auditLogs/signIns?$filter=userId eq '"+user.id+"'&$top=25");return{ok:true,items:j.value.map(s=>({createdDateTime:s.createdDateTime,appDisplayName:s.appDisplayName,status:s.status?.errorCode?'Failure: '+s.status.failureReason:'Success',ipAddress:s.ipAddress,location:[s.location?.city,s.location?.countryOrRegion].filter(Boolean).join(', ')}))}}catch(e){return{ok:false,error:e.message}}},
  async dirAudits(user){if(!this.live()){const m=mockState();return{ok:true,items:(m.dirAudits||[]).filter(s=>s.target===user.id).map(s=>({activityDateTime:new Date(Date.now()+s.t*864e5).toISOString(),activityDisplayName:s.activity,initiatedBy:s.by,result:s.result,details:s.details}))}}
    try{const j=await graph('GET',"/auditLogs/directoryAudits?$filter=targetResources/any(t:t/id eq '"+user.id+"')&$top=25");return{ok:true,items:j.value.map(a=>({activityDateTime:a.activityDateTime,activityDisplayName:a.activityDisplayName,initiatedBy:a.initiatedBy?.user?.userPrincipalName||a.initiatedBy?.app?.displayName||'unknown',result:a.result,details:(a.targetResources||[]).map(t=>t.displayName).filter(Boolean).join(', ')}))}}catch(e){return{ok:false,error:e.message}}},
  async health(){const t=performance.now();try{if(!this.live()){await sleep(120);return{ok:true,mode:'mock',ms:Math.round(performance.now()-t)}}await graph('GET','/organization?$select=displayName');return{ok:true,mode:'live',ms:Math.round(performance.now()-t)}}catch(e){return{ok:false,mode:'live',ms:Math.round(performance.now()-t),error:e.message}}}
};

/* ================= ServiceNow adapter ================= */
function snowFetch(method,path,body){const c=S.creds;if(!c.snowUrl||!c.snowUser)throw new Error('ServiceNow instance URL / credentials not configured');return fetch(c.snowUrl.replace(/\/$/,'')+path,{method,headers:{Authorization:'Basic '+btoa(c.snowUser+':'+c.snowPass),'Content-Type':'application/json',Accept:'application/json'},body:body?JSON.stringify(body):undefined}).then(async r=>{const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||('ServiceNow '+r.status));return j.result})}
const Snow={
  live:()=>S.creds.snowMode==='live',
  async createIncident(short,desc,opts={}){if(!this.live()){const m=mockState();const inc={sys_id:uid(),number:'INC00'+(m.seq++),short_description:short,description:desc,state:'2',opened:now(),work_notes:[],opened_by:S.user.username,...opts};m.incidents.unshift(inc);saveMock(m);return inc}
    const r=await snowFetch('POST','/api/now/table/incident',{short_description:short,description:desc,category:'software',urgency:opts.urgency||'3',impact:opts.impact||'3',comments:'Opened by Capgemini Identity MCP Console ('+S.user.username+')'});return{sys_id:r.sys_id,number:r.number}},
  async workNote(inc,note){if(!this.live()){const m=mockState();const i=m.incidents.find(x=>x.sys_id===inc.sys_id);if(i)i.work_notes.push({t:now(),note,by:S.user.username});saveMock(m);return}await snowFetch('PATCH','/api/now/table/incident/'+inc.sys_id,{work_notes:note})},
  async resolve(inc,note){if(!this.live()){const m=mockState();const i=m.incidents.find(x=>x.sys_id===inc.sys_id);if(i){i.state='6';i.close_code=S.creds.closeCode;i.close_notes=note;i.work_notes.push({t:now(),note:'Resolved: '+note,by:S.user.username})}saveMock(m);return}
    await snowFetch('PATCH','/api/now/table/incident/'+inc.sys_id,{state:S.creds.resolvedState||'6',close_code:S.creds.closeCode,close_notes:note,resolved_by:S.creds.snowUser})},
  async health(){const t=performance.now();try{if(!this.live()){await sleep(90);return{ok:true,mode:'mock',ms:Math.round(performance.now()-t)}}await snowFetch('GET','/api/now/table/incident?sysparm_limit=1&sysparm_fields=number');return{ok:true,mode:'live',ms:Math.round(performance.now()-t)}}catch(e){return{ok:false,mode:'live',ms:Math.round(performance.now()-t),error:e.message}}}
};

/* ================= AI adapter (OpenAI-compatible) ================= */
const AI={
  live:()=>S.creds.aiMode==='live'&&!!S.creds.aiUrl,
  async chat(system,user,json=true){const c=S.creds;const body={model:c.aiModel||'gpt-4o',temperature:0,messages:[{role:'system',content:system},{role:'user',content:user}]};if(json)body.response_format={type:'json_object'};
    const r=await fetch(c.aiUrl,{method:'POST',headers:{'Content-Type':'application/json','api-key':c.aiKey,Authorization:'Bearer '+c.aiKey},body:JSON.stringify(body)});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||('AI '+r.status));const txt=j.choices?.[0]?.message?.content||'';return json?JSON.parse(txt.replace(/```json|```/g,'').trim()):txt}
};

/* ================= Record any write as incident + audit ================= */
async function recordAction(action,targetUpn,detail,fn){
  if(!can('write'))throw new Error('Your role (Viewer) is read-only');
  let inc=null,status='success',err='';
  try{await fn()}catch(e){status='error';err=e.message}
  try{inc=await Snow.createIncident('[IAM Console] '+action+' — '+targetUpn,'Action: '+action+'\nTarget: '+targetUpn+'\nDetails: '+detail+'\nPerformed by: '+S.user.username+' via Identity MCP Console\nResult: '+status+(err?' — '+err:''));
    if(status==='success')await Snow.resolve(inc,'Automated change completed successfully via Identity MCP Console.')}catch(e){toast('ServiceNow incident could not be created','err',e.message)}
  audit(action,targetUpn,status,detail+(err?' — '+err:''),inc?.number);
  if(status==='success')toast(action+' completed','ok',inc?('Tracked as '+inc.number+' (resolved)'):'');else toast(action+' failed','err',err+(inc?' · '+inc.number:''));
  if(status!=='success')throw new Error(err);
  return inc;
}
