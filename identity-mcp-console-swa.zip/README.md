# Capgemini Identity MCP Console — Azure Static Web Apps package

Static, single-page console for identity operations across Microsoft Entra ID and ServiceNow, with AI-assisted L1/L2 investigation. No build step; deploy the folder as-is.

```
index.html                     app shell and all pages
css/styles.css                 Capgemini design tokens and components
js/core.js                     storage, encryption, session, Entra / ServiceNow / AI adapters
js/app.js                      pages, JML flows, NLP console, investigation engine, alerts, audit
staticwebapp.config.json       SWA routing + security headers (CSP allows Graph, login, ServiceNow, Azure OpenAI)
swa-cli.config.json            for `swa deploy` from a laptop
.github/workflows/…yml         GitHub Actions deploy (optional)
```

## Deploy

**Option A — SWA CLI from your laptop (no GitHub needed)**
```bash
npm install -g @azure/static-web-apps-cli
az login
swa deploy ./ --env production --app-name <your-swa-name> --resource-group <rg>
```
Or open the folder in VS Code with the *Azure Static Web Apps* extension and choose *Deploy*.

**Option B — GitHub**
Push this folder to a repo, create a Static Web App in the portal pointing at it (app location `/`, no API, no output folder), and add the generated deployment token as the `AZURE_STATIC_WEB_APPS_API_TOKEN` secret. The included workflow handles the rest.

## After deployment

1. **Entra ID app registration** — Authentication → add platform *Single-page application* with redirect URI `https://<your-app>.azurestaticapps.net/` (trailing slash matters). API permissions (delegated): `User.ReadWrite.All`, `Group.ReadWrite.All`, `AppRoleAssignment.ReadWrite.All`, `Directory.Read.All`, `AuditLog.Read.All` — grant admin consent.
2. **ServiceNow** — System Web Services → REST → CORS Rules → new rule: REST API *Table API*, domain `https://<your-app>.azurestaticapps.net`, methods GET/POST/PATCH.
3. **AI (optional)** — any OpenAI-compatible chat-completions endpoint. If yours is not on `*.openai.azure.com`, `*.services.ai.azure.com` or `api.openai.com`, add its host to `connect-src` in `staticwebapp.config.json`.
4. Sign in (admin / Admin@123 — change it under Manage users), open *My credentials*, enter tenant/client IDs and the ServiceNow instance, flip each connector to **Live**, save.

## Notes

- Mock mode works with zero configuration and seeds a full demo story (Directory → JML → Investigate `jane@contoso.com` → Alert → Fix Now → resolved incident).
- Console accounts, audit log and alerts are stored in the browser (localStorage) of the machine you use. Connector credentials are AES-GCM encrypted with a key derived from your console password.
- Sign-in to Entra is delegated (MSAL popup); no client secret is stored anywhere.
- Only the `staticwebapp.config.json` CSP `connect-src` needs editing if you point at a self-hosted ServiceNow domain that is not `*.service-now.com`.
